<?php include("layout/head.php"); ?>
<!-- breadcroumb-area -->
<div class="zmovo-breadcroumb-area">
    <div class="zmovo-breadcroumb-bg">
        <div class="container">
            <div class="zmovo-breadcroumb-inner text-center">
                <h2>Videos</h2>
            </div>
        </div>
    </div>
</div>
<!-- End breadcroumb-area -->
<div class="zmoto-inner-page">
    <div class="zmovo-product-page pt-50">
        <div class="container">
            <div class="zmovo-product-items">
                <div class="zmovo-product-items-inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="zmovo-product-with-sedbar">
                                <div class="row">
                                    <!-- Left -->
                                    <div class="col-lg-3">
                                        <div class="zmovo-widget">
                                            <h2 id="hidden-cat" class="widget-title mb-30 hidden-cat"><span>Top 10 Categories</span></h2>
                                            <div class="zmovo-category-menu catmenu" id="catmenu">
                                                <ul class="nav" role="tablist">
                                                <?php
                                        $cat = array();
                                        $i = 1;
                                    $e = 0;
                                    $sql = "SELECT * FROM category order by id desc LIMIT 0 , 10";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                    $cat[$e] = $row;
                                    $cat[$e]['srno'] = $i;
                                    $i++;
                                    $e++;
                                    }
                                    } else {
                                    echo "0 results";
                                    }

                                                                    ?>
                                    <?php if(!empty($cat)){
							        foreach($cat as $key => $value){
                                       ?>
                                        <li <?php if($key==0) {?>class="active"<?php }?> > <a href="#grid<?php echo $value['id'];?>" <?php if($key==1) {?>class="active show" <?php }?>  role="tab" data-toggle="tab"><?php echo $value['name'];?></a></li>
                                        <?php
                                        }
                                    }
                                    ?>
                                                </ul>    
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Left -->
                                    <!-- Right -->
                                    <div class="col-lg-9">
                                        <!-- Product Filter -->
                                        <div class="product-filter mb-30">
                                            <div class="product-filter-inner">
                                                <div class="row">
                                                    <!-- PAGINATION -->
                                                    <div class="ccol-12 col-md-4 col-lg-4 col-xl-4 pro-pagination sm-width">
                                                        <div class="product-filter-list">
                                                            <div class="pagination-wrapper">
                                                                <nav aria-label="navigations">
                                                                    <ul class="pagination">
                                                                        <li class="page-item"><a class="page-link pagefirst" href="#"><i class="fa fa-angle-left"></i></a></li>
                                                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                                        <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                                        <li class="page-item active"><a class="page-link" href="#">3</a></li>
                                                                        <li class="page-item"><a class="page-link lastpage" href="#"><i class="fa fa-angle-right"></i></a></li>
                                                                    </ul>
                                                                </nav>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- END PAGINATION -->
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end Product Filter -->
                                        <div class="zmoto-products">
                                            <div class="zmovo-product-list">
                                            <?php
                                        $cat = array();
                                        $i = 1;
                                    $e = 0;
                                    $sql = "SELECT * FROM category order by id desc LIMIT 0 , 10";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                    $cat[$e] = $row;
                                    $cat[$e]['srno'] = $i;
                                    $i++;
                                    $e++;
                                    }
                                    } else {
                                    echo "0 results";
                                    }

                                                                    ?>
                                    <?php if(!empty($cat)){
							        foreach($cat as $key1 => $value){
                                       ?>
                                        <div <?php if($key1==0) {?> class="tab-pane fade active in show"<?php } else {?>class="tab-pane fade in" <?php }?>  
                                        id="grid<?php echo $value['id'];?>" role="tabpanel">
                                                    <div class="row">
                                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                                        <?php
                            $video = array();
                            $i = 1;
                        $e = 0;
                        $id=$value['id'];
                        $sql = "SELECT * FROM video where `category_id`='$id'  order by id desc ";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                        $video[$e] = $row;
                        $video[$e]['srno'] = $i;
                        $i++;
                        $e++;
                        }
                        } else {
                        echo "0 results";
                        }
                        ?>
                                    <?php if(!empty($cat)){
							        foreach($video as $values){
                                        ?>
                                                            <div class="item">
                                                                <div class="zmovo-video-item-box">
                                                                    <div class="zmovo-video-box-inner">
                                                                        <div class="zmovo-v-box-img gradient">
                                                                            <img src="upload/<?=$values['image'];?>" alt="<?=$values['name'];?>">
                                                                            <div class="ply-btns">
                                                                                <a href="<?=$values['link'];?>" data-video-url="upload/<?=$values['image'];?>" class="ply-btn video-popup"><img src="upload/<?=$values['image'];?>" alt="<?=$values['name'];?>"></a>
                                                                            </div>
                                                                            <div class="zmovo-v-box-content">
                                                                                <a href="<?=$values['link'];?>"><?=$values['name'];?></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php
                                                            }
                                                        }?>
                                                        </div>
                                                    </div>
                                                </div>
                                        <?php
                                        }
                                    }
                                    ?>
                                                
                                            </div>
                                        </div>
                                        <!-- Product Filter -->
                                        <div class="product-filter">
                                            <div class="product-filter-inner">
                                                <div class="row">
                                                    <!-- LIST VIEW OR GRID VIEW -->
                                                    <!-- PAGINATION -->
                                                    <div class="ccol-12 col-md-4 col-lg-4 col-xl-4 pro-pagination sm-width">
                                                        <div class="product-filter-list">
                                                            <div class="pagination-wrapper">
                                                                <nav aria-label="navigations">
                                                                    <ul class="pagination">
                                                                        <li class="page-item"><a class="page-link pagefirst" href="#"><i class="fa fa-angle-left"></i></a></li>
                                                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                                        <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                                        <li class="page-item active"><a class="page-link" href="#">3</a></li>
                                                                        <li class="page-item"><a class="page-link lastpage" href="#"><i class="fa fa-angle-right"></i></a></li>
                                                                    </ul>
                                                                </nav>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- END PAGINATION -->
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end Product Filter -->
                                    </div>
                                    <!-- End Right -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('layout/foot.php');?>

