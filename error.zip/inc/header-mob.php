<header class="tabMobileView header navbar fixed-top d-lg-none">
        <div class="nav-toggle">
                <a href="javascript:void(0);" class="nav-link sidebarCollapse" data-placement="bottom">
                    <i class="flaticon-menu-line-2"></i>
                </a>
            <!-- <a href="index.html" class=""> <img src="assets/img/logo-3.png" class="img-fluid" alt="logo"></a> -->
        </div>
        <ul class="nav navbar-nav">
            <li class="nav-item d-lg-none"> 
                <!--<form class="form-inline justify-content-end" role="search">-->
                <!--    <input type="text" class="form-control search-form-control mr-3">-->
                <!--</form>-->
            </li>
        </ul>
    </header>