<header class="zmovo-header">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-2 zmovo-logos">
                        <div class="zmovo-logo">
                            <a href="index.php"><img src="image/logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8 zmovo-menus">
                        <div class="main-menu">
                            <div class="navigation">
                                <div class="menu-container">
                                    <div id="navigation">
                                        <ul>
                                            <li class="active has-sub"><span class="submenu-button"></span><a href="index.php">Home</a>
                                            </li>
                                            <!-- <li><a href="about.php">About</a></li> -->
                                            <li class="has-sub"><span class="submenu-button"></span><a href="#">Category</a>
                                                <ul>
                                                    <li class="has-sub"><span class="submenu-button"></span><a href="category-listing.php">Video</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <!-- <li><a href="contact.php">Contact Us</a></li> -->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
            </div>
        </header>