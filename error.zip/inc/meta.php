<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Zmovo - Online Movie Video And TV Show HTML Bootstrap 4 Template">
<meta name="keywords" content="Zmovo - Online Movie Video And TV Show HTML Bootstrap 4 Template">
<meta name="author" content="Themepul">