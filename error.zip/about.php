<?php include("layout/head.php"); ?>
 <!-- breadcroumb-area -->
 <div class="zmovo-breadcroumb-area">
            <div class="zmovo-breadcroumb-bg">
                <div class="container">
                    <div class="zmovo-breadcroumb-inner text-center">
                        <h2>About Us</h2>
                        <span>about Us</span>
                    </div>
                </div>
            </div>
        </div>
        <!-- End breadcroumb-area -->
        <div class="zmoto-inner-page">
            <div class="zmovo-about-page">
                <div class="zmovo-abouts pt-50">
                    <div class="container">
                        <div class="row align-items-start">
                            <div class="col-lg-7">
                                <div class="zmovo-about-content">
                                    <h2>Welcome To <span class="c1">Our Website</span></h2>
                                    <p>Proin fringilla vulputate lorem quis congue. Mauris lacinia gravida ultrices. Phasellus consectetur pellentesque. Vestibulum eu ligula cursus nisi ultrices laoreet iaculis sed lum non dolor fermentum, consequat risus non, auctor nisi. Nunc sodales blandit lum auctor nibh varius metus volutpat, et sollicitudin massa ornare. Donec rutrum urna tempor, a euismod massa porttitor. Donec at sapien non orci blandit placerat nec vitae diam dui, facilisis eget risus a, scelerisque molestie sem. Suspendisse convallis, lorem bus feugiat, elit turpis rutrum justo, eget dapibus leo eros quis tellus. Suspendisse varius fermentum varius fermentum.</p>
                                    <p class="pt-30">Proin fringilla vulputate lorem quis congue. Mauris lacinia gravida ultrices. Phasellus consectetur pellentesque. Vestibulum eu ligula cursus nisi ultrices laoreet iaculis sed lum non dolor fermentum, consequat risus non,</p>
                                    <div class="zmovo-signature pt-4">
                                        <img src="image/signture.png" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="zmovo-about-img">
                                    <img src="image/about.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="zmovo-counters pt-50">
                    <div class="container align-items-center">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="zmovo-counter-items">
                                    <div class="zmovo-counter-number">
                                        <span>56,825</span>
                                    </div>
                                    <div class="zmovo-counter-text">
                                        <h4>video</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="zmovo-counter-items">
                                    <div class="zmovo-counter-number">
                                        <span>50,825</span>
                                    </div>
                                    <div class="zmovo-counter-text">
                                        <h4>Commits</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="zmovo-counter-items">
                                    <div class="zmovo-counter-number">
                                        <span>825</span>
                                    </div>
                                    <div class="zmovo-counter-text">
                                        <h4>Team Members</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="zmovo-counter-items">
                                    <div class="zmovo-counter-number">
                                        <span>50%</span>
                                    </div>
                                    <div class="zmovo-counter-text">
                                        <h4>First years of use</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="zmovo-team-section arow-icon">
                    <div class="container">
                        <div class="zmovo-hadidng pt-50 pb-30">
                            <h2><span>Our Team</span></h2>
                        </div>
                        <div class="zmovo-teams" id="team">
                            <div class="item">
                                <div class="zmovo-team">
                                    <img src="image/team/1.jpg" alt="">
                                    <div class="zmovo-team-content">
                                        <div class="zmovo-team-social">
                                            <ul>
                                                <li class="tfb"><a href=""><span class="fa fa-facebook"></span></a></li>
                                                <li class="ttw"><a href=""><span class="fa fa-twitter"></span></a></li>
                                                <li class="tin"><a href=""><span class="fa fa-instagram"></span></a></li>
                                            </ul>
                                        </div>
                                        <div class="zmovo-team-title">
                                            <a href="">Jon kmpro kellys</a>
                                            <h4>director</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="zmovo-team">
                                    <img src="image/team/2.jpg" alt="">
                                    <div class="zmovo-team-content">
                                        <div class="zmovo-team-social">
                                            <ul>
                                                <li class="tfb"><a href=""><span class="fa fa-facebook"></span></a></li>
                                                <li class="ttw"><a href=""><span class="fa fa-twitter"></span></a></li>
                                                <li class="tin"><a href=""><span class="fa fa-instagram"></span></a></li>
                                            </ul>
                                        </div>
                                        <div class="zmovo-team-title">
                                            <a href="">Jon kmpro kellys</a>
                                            <h4>director</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="zmovo-team">
                                    <img src="image/team/3.jpg" alt="">
                                    <div class="zmovo-team-content">
                                        <div class="zmovo-team-social">
                                            <ul>
                                                <li class="tfb"><a href=""><span class="fa fa-facebook"></span></a></li>
                                                <li class="ttw"><a href=""><span class="fa fa-twitter"></span></a></li>
                                                <li class="tin"><a href=""><span class="fa fa-instagram"></span></a></li>
                                            </ul>
                                        </div>
                                        <div class="zmovo-team-title">
                                            <a href="">Jon kmpro kellys</a>
                                            <h4>director</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="zmovo-team">
                                    <img src="image/team/4.jpg" alt="">
                                    <div class="zmovo-team-content">
                                        <div class="zmovo-team-social">
                                            <ul>
                                                <li class="tfb"><a href=""><span class="fa fa-facebook"></span></a></li>
                                                <li class="ttw"><a href=""><span class="fa fa-twitter"></span></a></li>
                                                <li class="tin"><a href=""><span class="fa fa-instagram"></span></a></li>
                                            </ul>
                                        </div>
                                        <div class="zmovo-team-title">
                                            <a href="">Jon kmpro kellys</a>
                                            <h4>director</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end team member -->
                <!-- FULL WIDHT BANNER -->
                <div class="zmovo-fullwidht-banner pt-50">
                    <div class="zmovo-fullwidth-b-inner">
                        <div class="zmovo-full-banner-bg">
                            <div class="zmovo-slide-content">
                                <div class="container">
                                    <div class="items" id="banner">
                                        <div class="item">
                                            <div class="zmovo-slide-ply-btn text-center">
                                                <a href="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA" class="video-popup"><img src="image/play-button.png" alt=""></a>
                                            </div>
                                            <div class="zmovo-slider-contetn">
                                                <div class="zmovo-slider-premium-tag">
                                                    <span class="c1-bg">Trailer</span>
                                                </div>
                                                <h2>Upcoming Movies 2019</h2>
                                                <a href="">The Happy Nutcracker and the Four Realms</a>
                                                <div class="zmovo-v-tag c2">
                                                    <span>Romance, English, 2019</span>
                                                </div>
                                                <div class="movie-time"><i class="fa fa-clock-o"></i><span>2 Hr 3 Min</span></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="zmovo-slide-ply-btn text-center">
                                                <a href="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA" class="video-popup"><img src="image/play-button.png" alt=""></a>
                                            </div>
                                            <div class="zmovo-slider-contetn">
                                                <div class="zmovo-slider-premium-tag">
                                                    <span class="c1-bg">Trailer</span>
                                                </div>
                                                <h2>Upcoming Movies 2019</h2>
                                                <a href="">The Happy Nutcracker and the Four Realms</a>
                                                <div class="zmovo-v-tag c2">
                                                    <span>Romance, English, 2019</span>
                                                </div>
                                                <div class="movie-time"><i class="fa fa-clock-o"></i><span>2 Hr 3 Min</span></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="zmovo-slide-ply-btn text-center">
                                                <a href="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA" class="video-popup"><img src="image/play-button.png" alt=""></a>
                                            </div>
                                            <div class="zmovo-slider-contetn">
                                                <div class="zmovo-slider-premium-tag">
                                                    <span class="c1-bg">Trailer</span>
                                                </div>
                                                <h2>Upcoming Movies 2019</h2>
                                                <a href="">The Happy Nutcracker and the Four Realms</a>
                                                <div class="zmovo-v-tag c2">
                                                    <span>Romance, English, 2019</span>
                                                </div>
                                                <div class="movie-time"><i class="fa fa-clock-o"></i><span>2 Hr 3 Min</span></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="zmovo-slide-ply-btn text-center">
                                                <a href="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA" class="video-popup"><img src="image/play-button.png" alt=""></a>
                                            </div>
                                            <div class="zmovo-slider-contetn">
                                                <div class="zmovo-slider-premium-tag">
                                                    <span class="c1-bg">Trailer</span>
                                                </div>
                                                <h2>Upcoming Movies 2019</h2>
                                                <a href="">The Happy Nutcracker and the Four Realms</a>
                                                <div class="zmovo-v-tag c2">
                                                    <span>Romance, English, 2019</span>
                                                </div>
                                                <div class="movie-time"><i class="fa fa-clock-o"></i><span>2 Hr 3 Min</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END FULL WIDHT BANNER -->
                <!-- VIDEO PLYLIST SECTION -->
                <div class="zmovo-video-plylist-section arow-icon">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="zmovo-video-list-inner">
                                    <div class="zmovo-hadidng pt-50 pb-30">
                                        <h2><span>Suggested Movies</span></h2>
                                    </div>
                                    <div class="zmovo-video-list-items">
                                        <!-- SLIDE MOVIE -->
                                        <div class="bigplay open1">
                                            <div class="item">
                                                <div class="zmovo-video-list-ply hover12">
                                                    <div class="hover-box">
                                                        <img class="show-video" src="image/video-play/1.jpg" alt="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                        <div class="zmovo-h-btn">
                                                            <a class="video-play-button show-video" href="#" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                                <span></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item">
                                                <div class="zmovo-video-list-ply hover12">
                                                    <div class="hover-box">
                                                        <img class="show-video" src="image/video-play/2.jpg" alt="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                        <div class="zmovo-h-btn">
                                                            <a class="video-play-button show-video" href="#" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                                <span></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END SLIDE MOVIE -->
                                        <div class="zmovo-v-list-items mt-30">
                                            <div class="row">
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item active">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/1.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">The Happy Nutcracker and the Four </a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/2.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">I Dream in Another Language </a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item mt-30">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/3.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">Horror Movie perfming Main Payal </a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item mt-30">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/4.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">Movie perfming Main Payal Hai</a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ALL VIEW -->
                                        <div class="button pt-30 text-center">
                                            <a href="" class="btn btn-radus">view all <span class="fa fa-angle-right"></span></a>
                                        </div>
                                        <!-- END ALL VIEW -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="zmovo-video-list-inner">
                                    <div class="zmovo-hadidng pt-50 pb-30">
                                        <h2><span>Action Movies</span></h2>
                                    </div>
                                    <div class="zmovo-video-list-items">
                                        <!-- SLIDE MOVIE -->
                                        <div class="bigplay" id="openbi">
                                            <div class="item">
                                                <div class="zmovo-video-list-ply hover12">
                                                    <div class="hover-box">
                                                        <img class="show-video1" src="image/video-play/2.jpg" alt="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                        <div class="zmovo-h-btn">
                                                            <a class="video-play-button show-video1" href="#" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                                <span></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item">
                                                <div class="zmovo-video-list-ply hover12">
                                                    <div class="hover-box">
                                                        <img class="show-video1" src="image/video-play/1.jpg" alt="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                        <div class="zmovo-h-btn">
                                                            <a class="video-play-button show-video1" href="#" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA">
                                                                <span></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END SLIDE MOVIE -->
                                        <div class="zmovo-v-list-items mt-30">
                                            <div class="row">
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/1.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">Hindi Dream in Movie Another </a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/2.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">perfming Movie Main Payal Hai</a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item mt-30">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/3.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">Nam lectus nibh auc consequat</a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-lg-6">
                                                    <div class="zmovo-v-list-item mt-30 active">
                                                        <div class="zmovo-v-list-i-img">
                                                            <img src="image/video-play/small/5.jpg" alt="">
                                                        </div>
                                                        <div class="zmovo-v-list-content">
                                                            <div class="zmovo-v-tag c2"><span>English,2019</span></div>
                                                            <a href="">Nutcracker The Happy and the Four </a>
                                                            <div class="movie-time"><i class="fa fa-clock-o c1"></i><span>2 Hr 3 Min</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ALL VIEW -->
                                        <div class="button pt-30 text-center">
                                            <a href="" class="btn btn-radus">view all <span class="fa fa-angle-right"></span></a>
                                        </div>
                                        <!-- END ALL VIEW -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END VIDEO PLYLIST SECTION -->
            </div>
        </div>
<?php include("layout/foot.php"); ?>