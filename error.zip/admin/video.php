<?php include("layout/head.php");
?>
<?php

session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
<script>
window.location = "/admin/sign-in.php";
</script>
<?php
    exit(header("Location:/".$url_data));
}
?>
<?php 
// select 
$pageslists = array();
$pages = array();
$pagesbc = array();
?>
<?php 
$i = 1;
$e = 0;
$sql = "SELECT * FROM video order by id desc";
$sqlpbc = "SELECT * FROM category order by id desc";
$resultpbc = $conn->query($sqlpbc);
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
if ($resultpbc->num_rows > 0) {
  // output data of each row
  while($rowpbc = $resultpbc->fetch_assoc()) {
    $pagesbc[$e] = $rowpbc;
  $pagesbc[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}

?>
<div id="content" class="main-content">
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h3>video <small> Panel</small></h3>
                <div class="crumbs">
                    <ul id="breadcrumbs" class="breadcrumb">
                        <li><a href="index.php"><i class="flaticon-home-fill"></i></a></li>
                        <li class="active"><a href="video_list.php">View video</a> </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 layout-spacing">
                <div class="statbox widget box box-shadow">
                    <div class="widget-header">
                        <div class="row">
                            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                <h4>Create video </h4>
                            </div>
                        </div>
                    </div>
                    <div class="widget-content widget-content-area">
                        <form id="videoForm" name="videoForm">
                            <div class="form-row mb-4">
                                <div class="form-group col-md-6">
                                    <label for="name">Title</label>
                                    <input type="text" class="form-control-rounded form-control" id="name" name="name"
                                        placeholder="Video Title" autocomplete="name" />
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="Name">Link</label>
                                    <input type="text" class="form-control-rounded form-control" id="link"
                                        name="link" placeholder="Video Link"  />
                                </div>
                            </div>
                            <div class="form-row mb-4">
                                <div class="form-group col-md-6">
                                    <label for="Category"> Category</label>
                                    <select class="form-control-rounded form-control" id="Category"
                                        name="category_id">
                                        <?php if(!empty($pagesbc)){
							    foreach($pagesbc as $value11){
							    ?>
                                        <option value="<?=$value11['id']?>">
                                            <?=$value11['name']; ?></option>
                                        <?php } } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="address">Image</label>
                                    <input type="file" class="form-control-rounded form-control" id="image"
                                        name="image"  />
                                </div>
                            </div>
                            <div class="form-row mb-4">
                                <div class="form-group col-md-6">
                                    <input type="hidden" name="submit-video" value="submit-video">
                                    <button type="submit"
                                        class="btn btn-button-7 btn-rounded mb-4 mt-3 submit-video">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$conn->close();
include("layout/foot.php");?>