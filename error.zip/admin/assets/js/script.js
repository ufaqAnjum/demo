
$(function () {
    $.ajaxSetup({
headers: {
    'X-CSRF-TOKEN':"{{ csrf_token() }}",
}
});
$("#videoForm").submit(function(e) { 
    var name = document.getElementById('name').value;
    var link = document.getElementById('link').value;
    var image = document.getElementById('image').value;
    var Category = document.getElementById('Category').value;
    
    e.preventDefault();
    var formData = new FormData(this);
     if(name.length == 0  ) {
    
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Name is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
    if(name.length > 50 || name.length < 3) {
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'The Name should  not be less than 3 and more than 50 Characters !',
    button: false,
    timer: 1500
    });
    return false;
    }
    if(link.length == 0  ) {
    
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Link is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
    if(image.length == 0  ) {
    
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Image is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
$(".submit-video").hide();
$.ajax({
    type: "POST",
    data:formData,
    cache:false,
    contentType: false,
    processData: false,
    url: "admin-function.php",
    dataType: "json",
    success: function(data) {
        if(data.success=="success")
        {
        swal({
     position: 'top-end', 
    icon: 'success',
   title: 'Video saved successfully !',
   button: false,
   timer: 1500,
  }).then((confirmed) => {
       $("#name").val('');
       $("#phone").val('');
       $("#address").val('');
       $("#service").val('');
       $(".submit-video").show();
 });
        }
    },
    error: function() {
    }
});
});
$("#emailUpdateForm").submit(function(e) {
    var email = document.getElementById('email').value;  
    e.preventDefault();
    var formData = new FormData(this);
   // email
if(email.length == 0  ) {

    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Email is required !',
    button: false,
    timer: 1500
    });
    return false;
    }
    
    if(!email.match(/^[A-Za-z\._\-[0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)) {
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Email Invalid !',
    button: false,
    timer: 1500
    });
    return false;
    
    }
     // 
$.ajax({
    type: "POST",
    data:formData,
    cache:false,
    contentType: false,
    processData: false,
    url: "admin-function.php",
    dataType: "json",
    success: function(data) {
        if(data.success=="success")
        {
        swal({
     position: 'top-end', 
    icon: 'success',
   title: 'Email Updated successfully !',
   button: false,
   timer: 1500,
  }).then((confirmed) => {
 });
        }
    },
    error: function() {
    }
});
});
$("#passwordUpdateForm").submit(function(e) {
    var password = document.getElementById('password').value;  
    e.preventDefault();
    var formData = new FormData(this);
   // password
   if(password.length == 0  ) {

    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Password is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
    if(password.length > 18 || password.length < 6) {
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'The Password should  not be less than 6 and more than 18 Characters !',
    button: false,
    timer: 1500
    });
    return false;
    }
    if (password.search(/[a-z]/i) < 0) {
        swal({
        position: 'top-end',
    icon: 'error',
    title: 'Your password must contain at least one letter.',
    button: false,
    timer: 1500
    });
    return false;
        }
        if (password.search(/[0-9]/) < 0) {
            swal({
        position: 'top-end',
    icon: 'error',
    title: 'Your password must contain at least one digit.',
    button: false,
    timer: 1500
    });
    return false; 
        }
     // 
$.ajax({
    type: "POST",
    data:formData,
    cache:false,
    contentType: false,
    processData: false,
    url: "admin-function.php",
    dataType: "json",
    success: function(data) {
        if(data.success=="success")
        {
        swal({
     position: 'top-end', 
    icon: 'success',
   title: 'Password Updated successfully !',
   button: false,
   timer: 1500,
  }).then((confirmed) => {
 });
        }
    },
    error: function() {
    }
});
});
$("#videoFormEdit").submit(function(e) {
    var name = document.getElementById('name').value;
    var link = document.getElementById('link').value;
    var image = document.getElementById('image').value;
    var Category = document.getElementById('Category').value;
    
    e.preventDefault();
    var formData = new FormData(this);
     if(name.length == 0  ) {
    
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Name is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
    if(name.length > 50 || name.length < 3) {
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'The Name should  not be less than 3 and more than 50 Characters !',
    button: false,
    timer: 1500
    });
    return false;
    }
    if(link.length == 0  ) {
    
    swal({
        position: 'top-end',
    icon: 'error',
    title: 'Link is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
$(".edit-video").hide();
$.ajax({
    type: "POST",
    data:formData,
    cache:false,
    contentType: false,
    processData: false,
    url: "admin-function.php",
    dataType: "json",
    success: function(data) {
        if(data.success=="success")
        {
        swal({
     position: 'top-end', 
    icon: 'success',
   title: 'Video Updated successfully !',
   button: false,
   timer: 1500,
  }).then((confirmed) => {
     $(".edit-video").show();
 });
        }
    },
    error: function() {
    }
});
});
// emailUpdateForm
// CategoryAddForm
$("#CategoryAddForm").submit(function(e) {
    var name = document.getElementById('name').value;
    e.preventDefault();
    var formData = new FormData(this);
     if(name.length == 0  ) {
    swal({
        position: 'top-end',
    icon: 'error',
    title: ' Category is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
    $(".submit__category").hide();
     $.ajax({
        type: "POST",
        data:formData,
        cache:false,
        contentType: false,
        processData: false,
        url: "admin-function.php",
        dataType: "json",
        success: function(data) {
            if(data.success=="success")
            {
            swal({
         position: 'top-end', 
        icon: 'success',
       title: ' Category saved successfully !',
       button: false,
       timer: 1500,
      }).then((confirmed) => {
           $("#name").val('');
           $(".submit__category").show();
     });
            }
        },
        error: function() {
    
        }
    });
    });
// CategoryAddForm
// CategoryEditForm
$("#CategoryEditForm").submit(function(e) {
        var name = document.getElementById('name').value;
    e.preventDefault();
    var formData = new FormData(this);
     if(name.length == 0  ) {
    
    swal({
        position: 'top-end',
    icon: 'error',
    title: ' Category is  required!',
    button: false,
    timer: 1500
    });
    return false;
    }
    $(".edit-_category").hide();
    $.ajax({
        type: "POST",
        data:formData,
        cache:false,
        contentType: false,
        processData: false,
        url: "admin-function.php",
        dataType: "json",
        success: function(data) {
            if(data.success=="success")
            {
            swal({
         position: 'top-end', 
        icon: 'success',
       title: ' Category Update Successfully !',
       button: false,
       timer: 1500,
      }).then((confirmed) => {
         if (confirmed) {
          }
          $(".edit-_category").show();
     });
           
            }
        },
        error: function() {
    
        }
    });
    });
// CategoryEditForm
});
// delete__category_details
function delete__category_details(sDelId) {
      swal({
              title: `Are You Sure Want To Delete This  Category?`,
              text: "If you delete this, it will be gone forever.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              // 
            $(".delete__category_details").hide();
            $.ajax({
			type: "POST",
			url: "admin-function.php",
			data: {delete__category_details:"delete__category_details",sDelId:sDelId},
			cache: false,
			success: function(data){
			    var a=JSON.parse(data).success;
			      if(a==1)
            {
            swal({
         position: 'top-end', 
        icon: 'success',
       title: 'Information Successfully Deleted !',
       button: false,
       timer: 1500,
      }).then((confirmed) => {
               location.reload('true');
     });
            }
            else{
                  $(".delete__category_details").show();
                swal({
         position: 'top-end', 
        icon: 'warning',
       title: 'This is in video: hence will not be deleted !',
       button: false,
       timer: 1500,
      }).then((confirmed) => {
     });
            }	   
	     }
	 });
        
            //
            }
          });
}
// delete__category_details
// delete_video_details
function delete_video_details(sDelId) {
      swal({
              title: `Are You Sure Want To Delete This Video?`,
              text: "If you delete this, it will be gone forever.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              // 
            $(".delete-video-details").hide();
            $.ajax({
			type: "POST",
			url: "admin-function.php",
			data: {delete_video_details:"delete_video_details",sDelId:sDelId},
			cache: false,
			success: function(data){
			    var a=JSON.parse(data).success;
			      if(a==1)
            {
            swal({
         position: 'top-end', 
        icon: 'success',
       title: 'Information Successfully Deleted !',
       button: false,
       timer: 1500,
      }).then((confirmed) => {
               location.reload('true');
     });
            }
            else{
                  $(".delete-video-details").show();
                swal({
         position: 'top-end', 
        icon: 'warning',
       title: 'This is in video: hence will not be deleted !',
       button: false,
       timer: 1500,
      }).then((confirmed) => {
         if (confirmed) {
              
          }
     });
            }	   
	     }
	 });
            //
            }
          });
}
// delete-video-details