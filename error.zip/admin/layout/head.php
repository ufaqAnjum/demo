<?php
error_reporting(1);
if(!empty($_SESSION['master'])){
    ?>
    <script>
        window.location = "admin/sign-in.php";
    </script>
    <?php
}
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Video</title>
    <?php include("./inc/meta.php");?>
    <?php include("./inc/style.php");?>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-RKJ9BXC9KY">
</script>
    <?php include("../db.php");?>
    <?php include("../url.php");?>
</head>
<body class="default-sidebar">
    <!-- Tab Mobile View Header -->
    	<?php include("./inc/header-mob.php");?>
    <!-- Tab Mobile View Header -->
    <!--  BEGIN NAVBAR  -->
    	<?php include("./inc/header.php");?>
    <!--  END NAVBAR  -->
    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">
        <!--<div class="overlay"></div>-->
        <div class="cs-overlay"></div>
        <!--  BEGIN SIDEBAR  -->
        	<?php include("./inc/sidebar.php");?>
        <!--  END SIDEBAR  -->
        