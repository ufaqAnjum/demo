<div class="sidebar-wrapper sidebar-theme">
            
            <div id="dismiss" class="d-lg-none"><i class="flaticon-cancel-12"></i></div>
            
            <nav id="sidebar">

                <ul class="navbar-nav theme-brand flex-row  d-none d-lg-flex">
                    <li class="nav-item d-flex">
                        <a href="index.php" class="navbar-brand">
                            <img src="../eklan/logo.png" class="img-fluid" alt="logo">
                        </a>
                        <p class="border-underline"></p>
                    </li>
                    <li class="nav-item theme-text">
                        <a href="index.php" class="nav-link" style="justify-content: center;"> <?php
                        echo $_SESSION['name'];
                        ?> </a>
                    </li>
                </ul>
                <ul class="list-unstyled menu-categories" id="accordionExample">
                    <li class="menu">
                        <a href="index.php"  class="dropdown-toggle" style="justify-content: center;">
                            <div class="">
                                <i class="fa-solid fa-gauge"></i>
                                <span>Dashboard</span>
                            </div>
                        </a>
                    </li>
                    <li class="menu">
                        <a href="#businessCategory" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                            <i class="fa-solid fa-business-time"></i>
                                <span>Category</span>
                            </div>
                            <div>
                                <i class="flaticon-right-arrow"></i>
                            </div>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="businessCategory"  data-parent="#accordionExample">
                            <li>
                                <a href="category.php">Create  Category</a>
                            </li>
                            <li>
                                <a href="category_list.php">View  Category</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu">
                        <a href="#client" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <i class="fa-solid fa-users"></i>
                                <span>Video</span>
                            </div>
                            <div>
                                <i class="flaticon-right-arrow"></i>
                            </div>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="client" data-parent="#accordionExample">
                            <li>
                                <a href="video.php">Create Video</a>
                            </li>
                            <li>
                                <a href="video_list.php">View Video</a>
                            </li>
                        </ul>
                    </li>
                  </ul>
            </nav>

        </div>