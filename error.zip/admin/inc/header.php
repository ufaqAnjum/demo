    <header class="header navbar fixed-top navbar-expand-sm">
        <a href="javascript:void(0);" class="sidebarCollapse d-none d-lg-block" data-placement="bottom"><i class="flaticon-menu-line-2"></i></a>
        <ul class="navbar-nav flex-row ml-lg-auto">
            <li class="nav-item dropdown user-profile-dropdown ml-lg-0 mr-lg-2 ml-3 order-lg-0 order-1">
                <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="flaticon-user-12"></span>
                </a>
                <div class="dropdown-menu  position-absolute" aria-labelledby="userProfileDropdown">
                    <a class="dropdown-item" href="user_profile.php">
                        <i class="mr-1 flaticon-user-6"></i> <span>My Profile</span>
                    </a>
                    <div class="dropdown-divider"></div>
                     <form class="form-login" action="admin-function.php" method="post">
                    <button class="btn btn-lg btn-gradient-warning btn-block btn-rounded mb-4 mt-5" name="logout" value="logout"  type="submit">
                        <a class="dropdown-item">
                            <i class="mr-1 flaticon-power-button"></i> <span>Log Out</span>
                         </a>
                    </button>
                    </form>
                </div>
            </li>
        </ul>
    </header>