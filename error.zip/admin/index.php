<?php include("layout/head.php");?>
<!--  BEGIN CONTENT PART  -->
<div id="content" class="main-content">
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <h3>Section</h3>
            </div>
        </div>
        <div class="row layout-spacing ">
            <div class="col-xl-3 mb-xl-0 col-lg-6 mb-4 col-md-6 col-sm-6 div-sec">
                <div class="widget-content-area  data-widgets br-4">
                    <div class="widget  t-order-widget">
                        <div class="media">
                            <div class="icon ml-2">
                                <i class="fa-brands fa-digital-ocean"></i>
                            </div>
                            <div class="media-body text-right">
                                <p class="widget-text mb-0">Categories</p>
                                <p class="widget-numeric-value"><?=$videoervice;?></p>
                            </div>
                        </div>
                        <p class="widget-total-stats mt-2"><a href="category_list.php">Categories</a></p>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 mb-xl-0 col-lg-6 mb-4 col-md-6 col-sm-6 div-sec">
                <div class="widget-content-area  data-widgets br-4">
                    <div class="widget  t-order-widget">
                        <div class="media">
                            <div class="icon ml-2">
                                <i class="fa-brands fa-digital-ocean"></i>
                            </div>
                            <div class="media-body text-right">
                                <p class="widget-text mb-0">Video</p>
                                <p class="widget-numeric-value"><?=$videoervice;?></p>
                            </div>
                        </div>
                        <p class="widget-total-stats mt-2"><a href="video_list.php">Video</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--  END CONTENT PART  -->
<?php include("layout/foot.php");?>