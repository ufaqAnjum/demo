<?php include("layout/head.php");
?>
<?php

session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
     <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
?>
<?php 
// select 
$pageslists = array();
$pages = array();
?>
<?php 
$i = 1;
$e = 0;
$sql = "SELECT * FROM category order by id desc";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
?>
  <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>Category <small> Panel</small></h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.php"><i class="flaticon-home-fill"></i></a></li>
                                <li class="active"><a href="category.php">Create Category</a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php
                if($_SESSION['role'] == 1  || $_SESSION['role'] == 2)
                {?>
                <?php
                }
                ?>
                <div class="row" id="cancel-row">
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Category List</h4>
                                    </div>                 
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="html5-extension" class="table table-striped table-bordered table-hover" style="width:100%">
							<thead>
							  <tr>
								<th>Sr.No</th>
								<th>Name</th>
								<th>Created By</th>
								<th>Created At</th>
								<th>Updated By</th>
								<th>Updated At</th>
								<th class="not-export-column">Action</th>
							  </tr>
							</thead>
							<tbody>
							    <?php if(!empty($pageslists)){
							    foreach($pageslists as $value){
							    ?>
							  <tr>
								<td><?=$value['srno']?></td>
								<td><?=$value['name']?></td>
										
										<td><?php 
								$id=$value['created_by'];
								$sqlu="SELECT name FROM users where id=$id";
								  $resultu = $conn->query($sqlu);
                                $rowu = $resultu->fetch_assoc();
                                    echo $rowu['name'];
								?></td>
								<td><?=$value['created_at']?></td>
										<td><?php 
								$id=$value['updated_by'];
								$sqlu="SELECT name FROM users where id=$id";
								  $resultu = $conn->query($sqlu);
                                $rowu = $resultu->fetch_assoc();
                                    echo $rowu['name'];
								?></td>
								<td><?=$value['updated_at']?></td>
								    <td class="text-center not-export-column">
                                                    <div class="dropdown custom-dropdown">
                                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink6" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class="flaticon-dot-three"></i>
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink6" x-placement="bottom-start" style="position: absolute; transform: translate3d(27px, 27px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                            <a class="dropdown-item" href="category_edit.php?id=<?=$value['id']?>">Edit</a>
                                             <button onClick="delete__category_details(<?=$value['id'];?>)" type="submit" class="delete__category_details" style="background-color: transparent;border: none;" name="delete__category_details"  value="submit" > Delete
								             </button>
                                                        </div>
                                                    </div>
                        		     </td>
							  </tr>
							  <?php } 
							  } else { ?>
							  <tr><td colspan="9">No Pages</td></tr>
							  <?php } ?>
							</tbody>
						  </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<?php
$conn->close();
include("layout/foot.php");?> 