<?php include("layout/head.php");
?>
<?php

session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
     <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
?>
<?php 
// select 
$pageslists = array();
$pages = array();
?>
<?php 
$i = 1;
$e = 0;
$sql = "SELECT * FROM category  order by id desc;";
$sqlp = "SELECT * FROM page order by id desc";
$result = $conn->query($sql);
$resultp = $conn->query($sqlp);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
if ($resultp->num_rows > 0) {
  // output data of each row
  while($rowp = $resultp->fetch_assoc()) {
    $pages[$e] = $rowp;
  $pages[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}

?>
  <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>Category<small> Panel</small></h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.php"><i class="flaticon-home-fill"></i></a></li>
                                <li class="active"><a href="category_list.php">View Category</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12"> 
                                        <h4>Create Category </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <form  id="CategoryAddForm" name="CategoryAddForm">
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="name">Category</label>
                                        <input type="text" class="form-control-rounded form-control" id="name" name="name" placeholder="Category" autocomplete="ame"/>
                                        </div>
                                    </div>
                                    <input type="hidden" name="submit__category" value="submit__category">
                                  <button type="submit" class="btn btn-button-7 btn-rounded mb-4 mt-3 submit__category">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include("layout/foot.php");?>
<?php $conn->close();?>