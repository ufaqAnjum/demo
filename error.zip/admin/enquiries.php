<?php include("layout/head.php");?> 
<?php

session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
     <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
if($_SESSION['role'] == 2 || $_SESSION['role'] == 4 )
{
    ?>
     <script>
        window.location = "/admin/index.php";
    </script>
     <?php
}
?>
<?php 
include("../db.php");
$file='new';
$fp = fopen(trim($_SERVER['DOCUMENT_ROOT']).'/'.$file.'.php',"wb");
$data= "<?php include('layout/head.php');?>".
         ".'sdsadasadsad'.".
       "<?php include('layout/foot.php');?>";
fwrite($fp,$data);
$get_file = file_get_contents('../landing-page.php');
file_put_contents(trim($_SERVER['DOCUMENT_ROOT']).'/'.$file.'.php', $get_file);
fclose($fp);
$enquiries = array();
$i = 1;
$e = 0;

$sql = "SELECT * FROM enquire";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  
    $enquiries[$e] = $row;
  echo  $enquiries[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
$conn->close();
?>
 <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>Enquiries Panel</h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.php"><i class="flaticon-home-fill"></i></a></li>
                                <li class="active"><a href="#">Enquiries </a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="row" id="cancel-row">
                
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Enquiries </h4>
                                    </div>                 
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="html5-extension" class="table table-striped table-bordered table-hover" style="width:100%">
							<thead>
							  <tr>
								<th>Sr. No</th>
								<th>Name</th>
								<th>Mobile</th>
								<th>Email</th>
								<th>Messages</th>
								<th>Date</th>
							  </tr>
							</thead>
							<tbody>
							    <?php if(!empty($enquiries)){
							    foreach($enquiries as $value){
							    ?>
							  <tr>
								<td><?=$value['srno']?></td>
								<td><?=$value['name']?></td>
								<td><?=$value['mob']?></td>
								<td><?=$value['email']?></td>
								<td><?=$value['message']?></td>
								<td><?=$value['created_at']?></td>
							  </tr>
							  <?php } 
							  } else { ?>
							  <tr><td colspan="6">No Enquiries</td></tr>
							  <?php } ?>
							</tbody>
						  </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
<?php include("layout/foot.php");?>        