<?php include("layout/head.php");
?>
<?php
session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
     <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
if($_SESSION['role'] == 2 || $_SESSION['role'] == 4 )
{
    ?>
     <script>
        window.location = "/admin/index.php";
    </script>
     <?php
}
?>
<?php 
if(!empty($_POST['submit'])){
  $page=$_POST['page'].'.php';
  $content=mysqli_real_escape_string($conn,$_POST['content']);
  $query1 = mysqli_query($conn, "select * from page_links where page='$page'");
	if(mysqli_num_rows($query1) == 0)
	{
  $res = "insert into page_links (des,page) values ('$content','$page')";
     if(mysqli_query($conn,$res)){
           ?>
    <script>
    alert("Information Successfully submitted");
        window.location = "http://localhost/video/admin/meta.php";
    </script>
    <?php 
        }
	}
	else
	{
	 echo   $res = "UPDATE `page_links` SET `des`='$content' WHERE `page`='$page'";
     if(mysqli_query($conn,$res)){
           ?>
    <script>
    alert("Information Successfully updated");
        window.location = "http://localhost/video/admin/meta.php";
    </script>
    <?php 
        }
	}
      
}
// select 
$pageslists = array();
$pages = array();
?>
<?php 
$i = 1;
$e = 0;

$sql = "SELECT * FROM page_links order by id desc";
$sqlp = "SELECT * FROM page order by id desc";
$result = $conn->query($sql);
$resultp = $conn->query($sqlp);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
if ($resultp->num_rows > 0) {
  // output data of each row
  while($rowp = $resultp->fetch_assoc()) {
    $pages[$e] = $rowp;
  $pages[$e]['srno'] = $i;
   $i++;
   $e++;
  }
} 
$conn->close();
?>
  <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>Meta <small> Panel</small></h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.html"><i class="flaticon-home-fill"></i></a></li>
                                <li class="active"><a href="#">Meta Tag</a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Meta Tag</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <form  method="post">
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">All Meta Section </label>
                                            <textarea type="text" class="form-control-rounded form-control" id="inputEmail4" name="content" placeholder="Meta Title">All Meta Section
                                            </textarea>
                                        </div>
                                    </div>
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Page</label>
                                            <select class="form-control-rounded form-control" id="page" name="page">
                                            <?php if(!empty($pages)){
							    foreach($pages as $value){
							    ?>
							    <option value="<?=$value['value']?>"><?=$value['name']?></option>
							    <?php } } ?>
							    </select>
                                        </div>
                                    </div>
                                  <button type="submit" name="submit" class="btn btn-button-7 btn-rounded mb-4 mt-3" value="submit">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" id="cancel-row">
                
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Meta Tag List</h4>
                                    </div>                 
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="html5-extension" class="table table-striped table-bordered table-hover" style="width:100%">
							<thead>
							  <tr>
								<th>Sr. No</th>
								<th>Pages</th>
								<th>Content</th>
								<th>Date</th>
								<th class="not-export-column">Action</th>
							  </tr>
							</thead>
							<tbody>
							    <?php if(!empty($pageslists)){
							    foreach($pageslists as $value){
							    ?>
							  <tr>
								<td><?=$value['srno']?></td>
								<td><?=$value['page']?></td>
								<td><textarea><?php echo $value['des']; ?></textarea></td>
								<td><?=$value['created_at']?></td>
								<td class="text-center not-export-column">
                                                    <div class="dropdown custom-dropdown">
                                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink6" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class="flaticon-dot-three"></i>
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink6" x-placement="bottom-start" style="position: absolute; transform: translate3d(27px, 27px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                            <a class="dropdown-item" href="admin_meta_view.php?id=<?=$value['id']?>">View</a>
                                                            <a class="dropdown-item" href="admin_meta_edit.php?id=<?=$value['id']?>">Edit</a>
                                                  <form  method="post" action="admin-function.php">
								         <input type="hidden" name="id" value="<?=$value['id']?>">
								         <button type="submit" name="delete-submit-meta" class="btn btn-button-7 btn-rounded mb-4 mt-3" value="submit">Delete</button>
								         </form>
                                                        </div>
                                                    </div>
                        		     </td>
							  </tr>
							  <?php } 
							  } else { ?>
							  <tr><td colspan="6">No Pages</td></tr>
							  <?php } ?>
							</tbody>
						  </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<?php include("layout/foot.php");?> 