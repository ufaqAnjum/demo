<?php include("layout/head.php");
?>
<?php

session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
     <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
?>
<?php 
// select 
$pageslists = array();
$pages = array();
$pagesbc = array();
?>
<?php 
$i = 1;
$e = 0;
$id=$_GET['id'];
$sql = "SELECT * FROM video where `id`='$id'";
$sqlpbc = "SELECT * FROM category order by id desc";
$resultpbc = $conn->query($sqlpbc);
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
if ($resultpbc->num_rows > 0) {
  // output data of each row
  while($rowpbc = $resultpbc->fetch_assoc()) {
    $pagesbc[$e] = $rowpbc;
  $pagesbc[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
?>
  <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>video <small>  Panel</small></h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.php"><i class="flaticon-home-fill"></i></a></li>
                                <?php
                                if($_SESSION['role'] == 1)
                                {
                                    ?>
                                    <li class="active"><a href="video_list.php">View video</a> </li>
                                    <?php
                                }
                                if($_SESSION['role'] == 2)
                                {
                                    ?>
                                    <li class="active"><a href="video_follow_up.php">View Follow Up video</a> </li>
                                    <?php
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php
                if($_SESSION['role'] == 1  || $_SESSION['role'] == 2)
                {?>
                <div class="row">
                    <div class="col-lg-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Edit video </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                 <?php if(!empty($pageslists)){
							    foreach($pageslists as $value){
							    ?>
                                <form id="videoFormEdit" name="videoFormEdit">
                                    <input type="hidden" id="videoId" value="<?=$value['id']?>" name="videoId">
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="name"> Name</label>
                                            <input type="text" class="form-control-rounded form-control" id="name" name="name" placeholder="Name" value="<?=$value['name']?>" autocomplete="name" />
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="phone">Link</label>
                                        <input type="text" class="form-control-rounded form-control" id="link" name="link" placeholder="Link" value="<?=$value['link']?>" />
                                        </div>
                                    </div>
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="Category"> Category</label>
                                        <select class="form-control-rounded form-control" id="Category" name="category_id"  autocomplete="bussiness category">
                                        <?php if(!empty($pagesbc)){
							    foreach($pagesbc as $value11){
							    ?>
							    <option
							    <?php
							    if($value['category_id']==$value11['id']) 
							    {
							    echo "selected";    
							    }
							    ?>
							    value="<?=$value11['id']?>" 
							     >
							    <?=$value11['name']; ?></option>
							    <?php } } ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="address">Image</label>
                                        <input type="file" class="form-control-rounded form-control" id="image" name="image" value="<?=$value['image']?>" />
                                        <input type="hidden" class="form-control-rounded form-control" name="imageb" value="<?=$value['image']?>" />
                                        </div>
                                    </div>
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="address">Image</label>
                                            <img src="../upload/<?=$value['image'];?>" title="image"  width="200">
                                        </div>
                                    </div>
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                    <input type="hidden" name="edit-video" value="edit-video" id="edit-video">
                                  <button type="submit"
                                  class="btn btn-button-7 btn-rounded mb-4 mt-3 edit-video">Update</button>
                                </form>
                                 <?php } 
							  } else { ?>
							  <tr><td colspan="6">No Pages</td></tr>
							  <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>
        </div>
<?php 
$conn->close();
include("layout/foot.php");?> 