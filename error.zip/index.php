<?php include('layout/head.php');?> 
        <!-- SLIDER SECTION --->
        <div class="zmovo-slider-area">
            <div class="items" id="slider">
                <div class="item">
                    <div class="zmovo-slider-contents">
                        <img src="image/slider/1.webp" alt="">
                        <!-- <div class="zmovo-slide-content">
                            <div class="container">
                                <div class="zmovo-slider-contetn">
                                    <div class="zmovo-slider-premium-tag">
                                        <span class="c2-bg">premium</span>
                                        <label>Period Adventure</label>
                                    </div>
                                    <a href="">Action Hindi Rebort Story</a>
                                    <div class="zmovo-slide-cat">
                                        <ul>
                                            <li><span>Category : </span>English Movies - 2019</li>
                                            <li><span>Genre : </span>Action, Drama </li>
                                        </ul>
                                    </div>
                                    <div class="zmovo-slide-ply-btn">
                                        <a href="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA" class="video-popup"><img src="image/play-button.png" alt="">Play Trailer</a>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="item">
                    <div class="zmovo-slider-contents">
                        <img src="image/slider/2.webp" alt="">
                        <!-- <div class="zmovo-slide-content">
                            <div class="container">
                                <div class="zmovo-slider-contetn">
                                    <div class="zmovo-slider-premium-tag">
                                        <span class="c2-bg">premium</span>
                                        <label>Period Adventure</label>
                                    </div>
                                    <a href="">Rebort Action Story 5</a>
                                    <div class="zmovo-slide-cat">
                                        <ul>
                                            <li><span>Category : </span>English Movies - 2019</li>
                                            <li><span>Genre : </span>Action, Drama </li>
                                        </ul>
                                    </div>
                                    <div class="zmovo-slide-ply-btn">
                                        <a href="" data-video-url="https://www.youtube.com/watch?v=CsVJoCKc9rA" class="video-popup"><img src="image/play-button.png" alt="">Play Trailer</a>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- END SLIDER SECTION --->
        <!-- VIDEO PLYLIST SECTION -->
        <div class="zmovo-video-plylist-section arow-icon">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="zmovo-video-list-inner">
                            <div class="zmovo-hadidng pt-50 pb-30">
                                <h2><span>Newly Married Couple Romantic</span></h2>
                            </div>
                            <div class="zmovo-video-list-items">
                                <!-- SLIDE MOVIE -->
                                <div class="bigplay open1">
                                    <div class="item">
                                        <div class="zmovo-video-list-ply hover12">
                                            <div class="hover-box">
                                                <img class="show-video" src="image/1.webp" alt="" data-video-url="https://www.youtube.com/watch?v=o4vb3vrM5l0">
                                                <div class="zmovo-h-btn">
                                                    <a class="video-play-button show-video" href="#" data-video-url="https://www.youtube.com/watch?v=o4vb3vrM5l0">
                                                        <span></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="zmovo-video-list-ply hover12">
                                            <div class="hover-box">
                                                <img class="show-video" src="image/2.webp" alt="" data-video-url="https://www.youtube.com/watch?v=e5hoH-lDQp0">
                                                <div class="zmovo-h-btn">
                                                    <a class="video-play-button show-video" href="#" data-video-url="https://www.youtube.com/watch?v=e5hoH-lDQp0">
                                                        <span></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="zmovo-video-list-inner">
                            <div class="zmovo-hadidng pt-50 pb-30">
                                <h2><span>Couple Romantic</span></h2>
                            </div>
                            <div class="zmovo-video-list-items">
                                <!-- SLIDE MOVIE -->
                                <div class="bigplay" id="openbi">
                                    <div class="item">
                                        <div class="zmovo-video-list-ply hover12">
                                            <div class="hover-box">
                                                <img class="show-video1" src="image/3.webp" alt="" data-video-url="https://www.youtube.com/watch?v=v5wycjzQEus">
                                                <div class="zmovo-h-btn">
                                                    <a class="video-play-button show-video1" href="#" data-video-url="https://www.youtube.com/watch?v=v5wycjzQEus">
                                                        <span></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="zmovo-video-list-ply hover12">
                                            <div class="hover-box">
                                                <img class="show-video1" src="image/4.webp" alt="" data-video-url="https://www.youtube.com/watch?v=W6hmYCZu2zg">
                                                <div class="zmovo-h-btn">
                                                    <a class="video-play-button show-video1" href="#" data-video-url="https://www.youtube.com/watch?v=W6hmYCZu2zg">
                                                        <span></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="zmovo-video-list-inner">
                            <div class="zmovo-video-list-items">
                                <div class="zmovo-v-list-items mt-30">
                                    <div class="row">
                                    <?php
                                        $cat = array();
                                        $i = 1;
                                    $e = 0;
                                    $sql = "SELECT * FROM category order by id desc LIMIT 0 , 10";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                    $cat[$e] = $row;
                                    $cat[$e]['srno'] = $i;
                                    $i++;
                                    $e++;
                                    }
                                    } else {
                                    echo "0 results";
                                    }

                                                                    ?>
                                    <?php if(!empty($cat)){
							        foreach($cat as $value){
                                       ?>
                                        <div class="col-sm-4 col-lg-4">
                                            <div class="zmovo-v-list-item active">
                                                <div class="zmovo-v-list-content">
                                                    <div class="zmovo-v-tag c2"><span><?php echo $value['name'];?></span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        }
                                    }?>
                                    </div>
                                </div>
                                <!-- ALL VIEW -->
                                <div class="button pt-30 text-center">
                                    <a href="category-listing.php" class="btn btn-radus">view all <span class="fa fa-angle-right"></span></a>
                                </div>
                                <!-- END ALL VIEW -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END VIDEO PLYLIST SECTION -->
        <!-- NEW ARRIVALS -->
        <?php
    $cat = array();
    $i = 1;
$e = 0;
$sql = "SELECT * FROM category order by id desc LIMIT 0 , 10";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
  $cat[$e] = $row;
  $cat[$e]['srno'] = $i;
   $i++;
   $e++;
  }
} else {
  echo "0 results";
}

							    ?>
                                    <?php if(!empty($cat)){
							        foreach($cat as $value){
                                       ?>
                                       <div class="zmovo-new-arrivals arow-icon">
            <div class="container">
                <div class="zmovo-arrivals-items">
                    <div class="zmovo-hadidng pt-50 pb-30">
                        <h2><span class="text-uppercase"><?php echo $value['name'];?></span></h2>
                    </div>
                    <!-- items -->
                    <div class="items" id="new-arrivle">
                    <?php
                            $video = array();
                            $i = 1;
                        $e = 0;
                        $id=$value['id'];
                        $sql = "SELECT * FROM video where `category_id`='$id'  order by id desc ";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                        $video[$e] = $row;
                        $video[$e]['srno'] = $i;
                        $i++;
                        $e++;
                        }
                        } else {
                        echo "0 results";
                        }
                        ?>
                                    <?php if(!empty($cat)){
							        foreach($video as $values){
                                        ?>
                                        <!-- ITEM -->
                        <div class="item">
                            <div class="zmovo-video-item-box">
                                <div class="zmovo-video-box-inner">
                                    <div class="zmovo-v-box-img gradient">
                                        <img src="upload/<?=$values['image'];?>" alt="<?=$values['name'];?>">
                                        <div class="ply-btns">
                                            <a href="<?=$values['link'];?>" data-video-url="upload/<?=$values['image'];?>" class="ply-btn video-popup"><img src="upload/<?=$values['image'];?>" alt="<?=$values['name'];?>"></a>
                                        </div>
                                        <div class="zmovo-v-box-content">
                                            <a href="<?=$values['link'];?>"><?=$values['name'];?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END ITEM -->
                    </div>
                    <!-- end items -->
                    <!-- ALL VIEW -->
                    <div class="button pt-50 text-center">
                        <a href="category-listing.php" class="btn btn-radus">view all <span class="fa fa-angle-right"></span></a>
                    </div>
                    <?php
                                    }
                                }
                                ?> 
                    <!-- END ALL VIEW -->
                </div>
            </div>
        </div>
                                       <?php
                                    }
                                }
							        ?>
                                    


        
        <!-- END NEW ARRIVALS -->
        <!-- FULL WIDHT BANNER -->
        <div class="zmovo-fullwidht-banner pt-50">
            <div class="zmovo-fullwidth-b-inner">
                <div class="zmovo-full-banner-bg">
                    <div class="zmovo-slide-content">
                        <div class="container">
                            <div class="items" id="banner">
                                <div class="item">
                                    <div class="zmovo-slide-ply-btn text-center">
                                        <a href="" data-video-url="https://www.youtube.com/watch?v=dctcJ8RvQr0" class="video-popup"><img src="image/img1.webp" alt=""></a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="zmovo-slide-ply-btn text-center">
                                        <a href="" data-video-url="https://www.youtube.com/watch?v=FMp5ZPqGzGA&t=149s" class="video-popup"><img src="image/img2.webp" alt=""></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END FULL WIDHT BANNER -->
        <?php
    $cat = array();
    $i = 1;
$e = 0;
$sql = "SELECT * FROM category order by id desc LIMIT 10,20";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
  $cat[$e] = $row;
  $cat[$e]['srno'] = $i;
   $i++;
   $e++;
  }
} else {
}

							    ?>
                                    <?php if(!empty($cat)){
							        foreach($cat as $value){
                                       ?>
        <!-- POPOLER SHOWS -->
        <div class="zmovo-Popular-item arow-icon">
            <div class="container">
                <div class="zmovo-Popular-items">
                    <div class="zmovo-hadidng pt-50 pb-30">
                        <h2><span class="text-uppercase"><?php echo $value['name'];?></span></h2>
                    </div>
                    <!-- items -->
                    <div class="items" id="popular-shows">
                    <?php
                            $video = array();
                            $i = 1;
                        $e = 0;
                        $id=$value['id'];
                        $sql = "SELECT * FROM video where `category_id`='$id'  order by id desc ";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                        $video[$e] = $row;
                        $video[$e]['srno'] = $i;
                        $i++;
                        $e++;
                        }
                        } else {
                        echo "0 results";
                        }
                        ?>
                                    <?php if(!empty($cat)){
							        foreach($video as $values){
                                        ?>
                        <!-- ITEM -->
                        <div class="item">
                            <div class="zmovo-video-item-box">
                                <div class="zmovo-video-box-inner">
                                    <div class="zmovo-v-box-img gradient">
                                        <img src="upload/<?=$values['image'];?>" alt="<?php echo $values['name'];?>">
                                        <div class="ply-btns">
                                            <a href="<?php echo $values['link'];?>" data-video-url="<?php echo $values['link'];?>" class="ply-btn video-popup"><img src="upload/<?=$value['image'];?>" alt="<?php echo $values['name'];?>"></a>
                                        </div>
                                        <div class="zmovo-v-box-content">
                                            <a href="<?php echo $values['link'];?>"><?php echo $values['name'];?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END ITEM -->
                         <?php
                         }
                        }
                        ?>
                    </div>
                    <!-- end items -->
                    <!-- ALL VIEW -->
                    <div class="button pt-50 text-center">
                        <a href="category-listing.php" class="btn btn-radus">view all <span class="fa fa-angle-right"></span></a>
                    </div>
                    <!-- END ALL VIEW -->
                </div>
            </div>
        </div>
        <!-- END POPOLER SHOWS -->       
         <?php
         }
        }
        ?>
<?php include("layout/foot.php"); ?>