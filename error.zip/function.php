<?php
include("db.php");
error_reporting();
// fetch client
if(!empty($_POST['fetch_video'])){
    $id=$_POST['id'];
    $sql = "SELECT * FROM our_client WHERE id='$id'";
    $result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
     $response = array("data"=>$row);
     echo json_encode($response);
        // echo json_encode(array("status"=>true,"response"=>$response));
  }
} else {
  echo "0 results";
}
$conn->close();
}
// fetch client
// Email Function
function dubai_email($from,$to,$name,$email,$phone,$message)
{
require 'class/class.smtp.php';
require 'class/class.phpmailer.php';
echo $to;
echo $email;
$email_msg='<!DOCTYPE html>
        <html>
        <style>
        table, th, td {
          border:1px solid black;
        }
        </style>
        <body>
        <h2>Enquiry Now</h2>
        <table style="width:100%;border:1px solid black;">
          <tr style="width:100%;">
            <th style="width:50%;"><b>Name</b></th>
            <th style="width:50%;"><b>Info</b></th>
          </tr>
          <tr style="width:100%;">
            <td style="width:50%;">Name</td>
            <td style="width:50%;">'.$name.'</td>
          </tr>
          <tr style="width:100%;">
            <td style="width:50%;">Email</td>
            <td style="width:50%;">'.$email.'</td>
          </tr>
          <tr style="width:100%;">
            <td style="width:50%;">Mobile</td>
            <td style="width:50%;">'.$phone.'</td>
          </tr>
          <tr style="width:100%;">
            <td style="width:50%;">Message</td>
            <td style="width:50%;">'.$message.'</td>
          </tr>
        </table>
        <p>The Best IELTS Training in Sharjah, Ajman.</p>
        </body>
        </html>';  
$mail = new PHPMailer();  
$mail->isSMTP();
$mail->Host     = 'smtp.example.com';
$mail->SMTPAuth = true;
$mail->Username = 'ufaq5787@gmail.com';  // sender gmail host              
$mail->Password = 'mintxkqlssdeqnlv'; // sender gmail host password         
$mail->SMTPSecure = 'tls';  // for encrypted connection                     
$mail->Port = 587;   // port for SMTP     
$mail->setFrom($email, 'SenderName'); 
$mail->addReplyTo($to, 'SenderName'); 
$mail->addAddress($to, "Receiver");  // receiver's email and name
$mail->Subject = 'Enquiry Now';
$mail->isHTML(true); 
$mail->Body = $email_msg; 
// Send email 
if(!$mail->send()){ 
    echo 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo; 
    die();
}else{ 
    echo 'Message has been sent.'; 
}}
// Email Function

// video
if(!empty($_POST['submit-video'])){
  $from  = "ufaq5787@gmail.com";
  $to  = "ufaq5787@gmail.com";
  $namefrom = "ufaq5787@gmail.com";
  $name=$_POST['name'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $message=$_POST['message'];
  dubai_email($from,$to,$name,$email,$phone,$message);
  $res = "insert into enquire (name,email,mob,message) values ('$_POST[name]','$_POST[email]','$_POST[phone]','$_POST[message]')";
     if(mysqli_query($conn,$res)){
           ?>
    <script>
    alert("Information Successfully submitted");
        window.location = "http://localhost/video";
    </script>
    <?php 
  
        }
}
// video
if(!empty($_POST['firstname'])){
        $res = "insert into trainingForm (tName,tMob,tEmail,tAddress,tQualification,tMsg) values ('$_POST[firstname]','$_POST[phone]','$_POST[email]','$_POST[address]','$_POST[qualification]','$_POST[msg]')";
        
        if(mysqli_query($conn,$res)){
           ?>
    <script>
    alert("Your Messages has been Submited Successfully !!!");
        window.location = "/";
    </script>
    <?php 
        }
    }
// Career
if(!empty($_POST['applyform'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $position=$_POST['position'];
    $country=$_POST['country'];
    $state=$_POST['state'];
    $city=$_POST['city'];
    $pincode=$_POST['pincode'];
    $startdate=$_POST['statedate'];
    $message=$_POST['message'];
  $res = "insert into career (name,email,phone,position,country,state,city,pincode,startdate,image,message) values ('$name','$email','$phone','$position','$country','$state','$city','$pincode','$startdate','$message')";
     if(mysqli_query($conn,$res)){
           ?>
    <script>
    alert("Information Successfully Submitted");
        window.location = "http://localhost/video/career.php";
    </script>
    <?php 
        }
}
// Career
// curPageName
if(!empty($_POST['curPageName'])){
    $curPageName=$_POST['curPageName'];
    $sql = "SELECT * FROM page_links where page='$curPageName'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  $title=$row['title'];
  $keyword=$row['keyword'];
  $des=$row['des'];
  $response = array("data"=>$row);
     echo json_encode($response);
  }
}
}
// curPageName