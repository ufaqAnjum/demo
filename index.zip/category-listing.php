<?php include("layout/head.php"); ?>
<!-- breadcroumb-area -->
<div class="zmovo-breadcroumb-area">
    <div class="zmovo-breadcroumb-bg">
        <div class="container">
            <div class="zmovo-breadcroumb-inner text-center">
                <h2>Videos</h2>
            </div>
        </div>
    </div>
</div>
<!-- End breadcroumb-area -->
<div class="zmoto-inner-page">
    <div class="zmovo-product-page pt-50">
        <div class="container">
            <div class="zmovo-product-items">
                <div class="zmovo-product-items-inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="zmovo-product-with-sedbar">
                                <div class="row">
                                    <!-- Left -->
                                    <div class="col-lg-3">
                                        <div class="zmovo-widget">
                                            <h2 id="hidden-cat" class="widget-title mb-30 hidden-cat"><span>Top 10
                                                    Categories</span></h2>
                                            <div class="zmovo-category-menu catmenu" id="catmenu">
                                                <ul class="nav" role="tablist">
                                                    <?php
                                        $cat = array();
                                        $i = 1;
                                    $e = 0;
                                    $sql = "SELECT * FROM category order by id desc LIMIT 0 , 10";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                    $cat[$e] = $row;
                                    $cat[$e]['srno'] = $i;
                                    $i++;
                                    $e++;
                                    }
                                    } else {
                                    echo "0 results";
                                    }

                                                                    ?>
                                                    <?php if(!empty($cat)){
							        foreach($cat as $key => $value){
                                       ?>
                                                    <li onclick="myFunction(<?php echo $value['id'];?>)">
                                                        <?php echo $value['name'];?></li>
                                                    <?php
                                        }
                                    }
                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Left -->
                                    <!-- Right -->
                                    <div class="col-lg-9">
                                        <div class="zmoto-products">
                                            <div class="zmovo-product-list">
                                               <div class="tab-pane  ">
                                                    <div class="row" id="pagination">
                                                        
                                                    </div>
                                                    <div class="row" id="recordNotFound">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Product Filter -->
                                        <div class="product-filter">
                                            <div class="product-filter-inner">
                                                <div class="row">
                                                    <!-- LIST VIEW OR GRID VIEW -->
                                                    <!-- PAGINATION -->
                                                    <div
                                                        class="col-md-12 col-lg-12 col-xl-12 pro-pagination sm-width">
                                                        <div class="product-filter-list">
                                                            <div class="pagination-wrapper">
                                                                <nav aria-label="navigations">
                                                                    <div class="holder" style="float:right;"></div>

                                                                </nav>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- END PAGINATION -->
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end Product Filter -->
                                    </div>
                                    <!-- End Right -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function myFunction(id) {
    getSectionImages(id);
}
getSectionImages(2);
function getSectionImages(id) {
    $.ajax({
        type: "POST",
        url: "function.php",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            "data": "data",
            "id": id
        },
        cache: false,
        success: function(data) {
            var htmlData = "";
            if (data != '') {
                var arrToBreak = JSON.parse(data);
                for (var i = 0; i < arrToBreak.length; i++) {
                    htmlData +='<div class="col-xl-4 col-lg-4 col-md-4">'+
                                    '<div class="item">'+
                                        '<div class="zmovo-video-item-box">'+
                                            '<div class="zmovo-video-box-inner">'+
                                                '<div class="zmovo-v-box-img gradient">'+
                                                    '<img src="upload/' + arrToBreak[i].image +'" alt="'+ arrToBreak[i].name +'">'+
                                                     '<div class="ply-btns">'+
                                                        '<a href="'+ arrToBreak[i].link +'" data-video-url="upload/"'+ arrToBreak[i].image +' class="ply-btn video-popup">'+
                                                            '<img src="upload/' + arrToBreak[i].image +'" alt="'+arrToBreak[i].name +'">'+
                                                        '</a>'+
                                                        '</div>'+
                                                '</div>'+
                                            '</div>'+
                                        '</div>'+
                                        '</div>'+
                                '</div>';
                       
                }
                $("#pagination").html(htmlData);
                $("#recordNotFound").html('');
                $('#pagination').show();
                $('#recordNotFound').hide();
                $('.pagination').css('display', 'block');
                
            } else {
                var htmlData =
                    "<div class='col-xl-12 col-lg-12 col-md-12' style='background-color:red;text-align:center;padding: 13px 0px 0px;'><p style='color:#fff;'>Record Not Found !</p></div>";
                $("#recordNotFound").html(htmlData);
                $("#pagination").html('');
                $('.pagination').css('display', 'none');
                $('#pagination').hide();
                $('#recordNotFound').show();

            }
            /*Pagination*/
                $(function(){

/* initiate the plugin */
$("div.holder").jPages({
  containerID  : "pagination",
  perPage      : 1,
  startPage    : 1,
  startRange   : 1,
  midRange     : 1,
  endRange     : 1
});

});
                /*End Pagination*/






        },
        error: function() {

        }
    });

}
$(function() {
    var id = 0;
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

});
</script>
<?php include('layout/foot.php');?>