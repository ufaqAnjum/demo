<?php include('./inc/footer.php');?>
<?php $conn->close();?>
<div class="to-top" id="back-top">
	<i class="fa fa-angle-up"></i>
</div>
</div>
<?php include('./inc/script.php');?>
</body>
</html>