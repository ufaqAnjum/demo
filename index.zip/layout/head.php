<!doctype html>
<html class="no-js" lang="en">
<head>
    <title>Video</title>
    <?php include('./inc/meta.php');?>
    <?php include('./inc/style.php');?>
    <?php include("./db.php");?>
    <?php include("./url.php");?>
</head>
<body>
    <div class="zmovo-main dark-bg">        
        <!-- Preloader -->
        <div class="zmovo-preloader">
            <div class="boxes">
                <div class="box">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
                <div class="box">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
                <div class="box">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
                <div class="box">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
        <?php include('./inc/header.php');?>