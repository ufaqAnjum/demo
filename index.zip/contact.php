<?php include('layout/head.php');?>
<div class="zmovo-breadcroumb-area">
            <div class="zmovo-breadcroumb-bg">
                <div class="container">
                    <div class="zmovo-breadcroumb-inner text-center">
                        <h2>Contact Us</h2>
                        <span>Contact Us</span>
                    </div>
                </div>
            </div>
        </div>
        <!-- End breadcroumb-area -->
        <div class="zmoto-inner-page">
            <div class="zmovo-contact-page">
                <div class="container">
                    <div class="map-area pt-50 pb-50">
                        <div id="map" data-height="568" data-width="568"></div>
                    </div>
                    <div class="zmovo-contactpage-area">
                        <div class="row">
                            <div class="col-lg-9">
                                <div class="comment-respond">
                                    <h2 class="title">Leave a Comment</h2>
                                    <div class="respons-box">
                                        <div class="form">
                                            <form action="#">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="name">Nick Name :</label>
                                                            <input id="name" class="form-control form-mane" required="" type="text">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="email">E-mail :</label>
                                                            <input id="email" class="form-control form-email" required="" type="email">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="message">Write a Message :</label>
                                                    <textarea id="message" class="form-control form-comment" cols="10" rows="8" name="comment" required=""></textarea>
                                                </div>
                                                <div class="buttons">
                                                    <a href="" class="btn btn-buttons">Submit</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="contact-widget">
                                    <h5 class="contact-widget-title no-margin"><span>Contact info</span></h5>
                                    <div class="textwidget">
                                        <p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed loram ipsum</p>
                                        <ul>
                                            <li>
                                                <label><i class="fa fa-map-marker"></i></label> dambo dika,USA rode #420</li>
                                            <li>
                                                <label><i class="fa fa-envelope"></i></label><a href="">zmovo@gamil.com</a></li>
                                            <li>
                                                <label><i class="fa fa-phone"></i></label>(+990 ) 987 25 145</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('layout/foot.php');?>