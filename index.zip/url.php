<?php
$url="http://localhost/video/";
$admin_url="http://localhost/video/admin/";
?>
