<?php include('layout/head.php');?>
<?php include('layout/foot.php');?>