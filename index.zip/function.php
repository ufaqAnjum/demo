<?php
include("db.php");
error_reporting();
// curPageName
if(!empty($_POST['data'])){
    $id=$_POST['id'];
    $i = 1;
$e = 0;
    $pageslists = array();
    $sql = "SELECT * FROM video where `category_id`='$id'  order by id desc ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}
echo json_encode($pageslists);
            
}
// curPageName