<?php include("layout/head.php");
?>
<?php
session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
    <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
?>
<?php 
// select 
$pageslists = array();
?>
<?php 
$i = 1;
$e = 0;
$email='';
 
$id=$_SESSION['id'];
$sql = "SELECT * FROM users where id='$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
  $user_id=$row['id'];
  $email=$row['email'];
   $i++;
   $e++;
  }
} 
$conn->close();
?>
  <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>User <small> Profile</small></h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.php"><i class="flaticon-home-fill"></i></a></li>
                                <li class="active"><a href="#">User Profile</a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php
                if($_SESSION['role'] == 1  || $_SESSION['role'] == 2)
                {?>
                <div class="row">
                    <div class="col-lg-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Update Details</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <form id="emailUpdateForm" name="emailUpdateForm">
                                     <input type="hidden" class="form-control-rounded form-control" id="userIdEmailUpdate" name="user_id_email_update" value="<?=$user_id;?>"/>
                                    <div class="form-row mb-4">
                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Email</label>
                                        <div class="input-group">
                                             <input type="email" class="form-control" id="email" name="emailvarify" value="<?=$email;?>" placeholder="Email" />
                                              <button class="btn btn-outline-secondary" type="submit">Edit</button>
                                            </div>
                                            </div>
                                        
                                    </div>
                                        </form>
                                <form id="passwordUpdateForm" name="passwordUpdateForm">
                                     <input type="hidden" class="form-control-rounded form-control" id="userIdPasswordUpdate" name="user_id_password_update" value="<?=$user_id;?>"/>                         
                                    <div class="form-row mb-4">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Password</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="password" name="passwordUpdate" placeholder="Password" />
                                          <button class="btn btn-outline-secondary" type="submit">Edit</button>
                                        </div>
                                        </div>
                                    </div>
                                </form>    
                                    <hr>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>
        </div>
<?php include("layout/foot.php");?> 