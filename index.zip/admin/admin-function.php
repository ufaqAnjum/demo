<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("../db.php");
include("../url.php");
session_start();
// <!--logout-->
if(!empty($_POST['logout'])){
 header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
     unset($_SESSION['role']);  
     unset($_SESSION['email']);  
     unset($_SESSION['name']);  
     unset($_SESSION['id']);  
      session_destroy();  
      $url_data=$url.'admin/sign-in.php';
      header("Location:".$url_data);
}
// <!--logout-->
// <!--submit--->
if(!empty($_POST['submit-video'])){
$name=$_POST["name"];
$link=$_POST["link"];
$category_id=$_POST["category_id"];
$status=0;
$created_by=$_SESSION['id'];
$tmpFilePath = $_FILES['image']['tmp_name'];
   if ($tmpFilePath != ""){
      $image = rand().$_FILES['image']['name'];
      $newFilePath = "../upload/" . $image;
      if(move_uploaded_file($tmpFilePath, $newFilePath)) {}
   }
$res = "insert into video (name,image,status,created_by,link,category_id) values ('$name','$image','$status','$created_by','$link','$category_id')";
        if(mysqli_query($conn,$res)){
          echo json_encode(array("success"=>'success'));
        }
}
// <!--submit--->
// <!--edit--->
if(!empty($_POST['edit-video'])){
$videoId=$_POST["videoId"];
$name=$_POST["name"];
$link=$_POST["link"];
$image=$_POST["imageb"];
$category_id=$_POST["category_id"];
$tmpFilePath = $_FILES['image']['tmp_name'];
   if ($tmpFilePath != ""){
    unlink('../upload/'.$image); 
      $image = rand().$_FILES['image']['name'];
      $newFilePath = "../upload/" . $image;
      if(move_uploaded_file($tmpFilePath, $newFilePath)) {}
   }
$updated_by=$_SESSION['id'];
$res = "UPDATE `video` SET `name`='$name',`image`='$image',`link`='$link',`category_id`='$category_id',`updated_by`='$updated_by' where `id`='$videoId'";
        if(mysqli_query($conn,$res)){
          echo json_encode(array("success"=>'success'));
        }
}
// <!--submit--->
// <!--delete--->
if(!empty($_POST['delete_video_details'])){
  $id=$_POST['sDelId'];

  $resultssbc =$conn->query("SELECT image,id FROM video WHERE id ='".$id."'");
	$rowssbc=$resultssbc->fetch_assoc();
	unlink('../upload/'.$rowssbc['image']);

  $res = "DELETE FROM video WHERE id='$id'"; 
  if(mysqli_query($conn,$res)){
   echo json_encode(array("success"=>1));                           
   }
}
// <!--delete--->
// <!--Password varify-->
if(!empty($_POST['passwordUpdate'])){
  $id=mysqli_real_escape_string($conn,$_POST['user_id_password_update']);
  $password=mysqli_real_escape_string($conn,$_POST['passwordUpdate']);
  $password=md5($password);
  $updated_by=$_SESSION['id'];
  $res = "UPDATE `users` SET `password`='$password',`updated_by`='$updated_by' where `id`='$id'";
        if(mysqli_query($conn,$res)){
            echo json_encode(array("success"=>'success'));
        }
}
// <!--Password varify-->
// <!--Email varify-->
if(!empty($_POST['emailvarify'])){
  $id=mysqli_real_escape_string($conn,$_POST['user_id_email_update']);
  $emailvarify=mysqli_real_escape_string($conn,$_POST['emailvarify']);
  $updated_by=$_SESSION['id'];
  $res = "UPDATE `users` SET `email`='$emailvarify',`updated_by`='$updated_by' where `id`='$id'";
        if(mysqli_query($conn,$res)){
            echo json_encode(array("success"=>'success'));
        }
}
// <!--Email varify-->

// <!--videoerviceCharge Add More-->

// <!--submit-FAQ-->
// <!--FAQ-Edit-->
// submit-sub-service
// <!--_category--->
if(!empty($_POST['submit__category'])){
    $name=mysqli_real_escape_string($conn,$_POST["name"]);
    $created_by=$_SESSION['id'];
    $res = "insert into category (name,created_by) values ('$name','$created_by')";
            if(mysqli_query($conn,$res)){
              echo json_encode(array("success"=>'success'));
        }
    }
// <!--submit-_category-->
// <!--edit-_category-->
if(!empty($_POST['edit-_category'])){
        $name=mysqli_real_escape_string($conn,$_POST["name"]);
        $id=$_POST["id"];
        $updated_by=$_SESSION['id'];
    $res = "UPDATE `category` SET `name`='$name',`updated_by`='$updated_by' where `id`='$id'";
            if(mysqli_query($conn,$res)){
              echo json_encode(array("success"=>'success'));
            }
    }
    // <!--edit-_category-->
    // <!--delete__category_details-->
if(!empty($_POST['delete__category_details'])){
    $id=$_POST['sDelId'];
    $query = mysqli_query($conn, "select * from video where category_id='$id'");
    if(mysqli_num_rows($query) != 0)
    {
        echo json_encode(array("success"=>0));
    }
    else
    {
        $res = "DELETE FROM category WHERE id='$id'";
           if(mysqli_query($conn,$res)){
         echo json_encode(array("success"=>1));
              }
    }
  }
  // <!--delete__category_details-->

?>