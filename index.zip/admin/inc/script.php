<script src="https://cdn.ckeditor.com/ckeditor5/40.1.0/classic/ckeditor.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="assets/js/app.js"></script>
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="assets/js/custom.js"></script>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<!--<script src="plugins/charts/chartist/chartist.js"></script>-->

<!--<script src="plugins/progressbar/progressbar.min.js"></script>-->
<!--<script src="assets/js/default-dashboard/default-custom.js"></script>-->

<!--<script src="assets/js/sweetalert2.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script src="assets/js/script.js"></script>

<!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
    <script src="plugins/table/datatable/datatables.js"></script>
    <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
    <script src="plugins/table/datatable/button-ext/dataTables.buttons.min.js"></script>
    <script src="plugins/table/datatable/button-ext/jszip.min.js"></script>    
    <script src="plugins/table/datatable/button-ext/buttons.html5.min.js"></script>
    <script src="plugins/table/datatable/button-ext/buttons.print.min.js"></script>
 <script>
        $('#html5-extension').DataTable( {
            dom: '<"row"<"col-md-12"<"row"<"col-md-6"B><"col-md-6"f> > ><"col-md-12"rt> <"col-md-12"<"row"<"col-md-5 mb-md-0 mb-5"i><"col-md-7"p>>> >',
            buttons: {
                buttons: [
                    { extend: 'copy', className: 'btn btn-default btn-rounded btn-sm mb-4',
                        exportOptions: {
             columns: ":not(.not-export-column)"
          }, },
                    { extend: 'csv', className: 'btn btn-default btn-rounded btn-sm mb-4' ,
                        exportOptions: {
             columns: ":not(.not-export-column)"
          },},
                    { extend: 'excel', className: 'btn btn-default btn-rounded btn-sm mb-4',
                        exportOptions: {
             columns: ":not(.not-export-column)"
          }, },
                    { extend: 'print', className: 'btn btn-default btn-rounded btn-sm mb-4',
                        exportOptions: {
             columns: ":not(.not-export-column)"
          },
                     }
                ]
            },
            "language": {
                "paginate": {
                  "previous": "<i class='flaticon-arrow-left-1'></i>",
                  "next": "<i class='flaticon-arrow-right'></i>"
                },
                "info": "Showing page _PAGE_ of _PAGES_"
            }
        } );
    </script>