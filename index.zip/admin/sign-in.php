<?php
include("../db.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(!empty($_POST["user"] && $_POST["password"]))
{
    $username=escapeChars($_POST["user"]);
    $password=md5($_POST["password"]);
    //  $query1 = mysqli_query($conn, "select * from users where email='$username'  ");
    $query1 = mysqli_query($conn, "select * from users where email='$username'  AND password='$password'");
	if(mysqli_num_rows($query1) == 0)
	{
	    ?>
	    <script>alert("Invalid Login Details");</script>
	    <?php
	}
	else
	{
	    session_start();
		$row1 = mysqli_fetch_assoc($query1);
		$_SESSION['master']=$username;
		$_SESSION['email']=$row1['email'];
		$_SESSION['role']=$row1['role'];
		$_SESSION['name']=$row1['name'];
		$_SESSION['id']=$row1['id'];
		?>
	<script>
	alert("Logged In");
	 window.location = "<?=$admin_url?>index.php";
	</script>
	<?php
	}
	
}
}
?>
<?php
function escapeChars($string) {
		$matchchar = array('/','"',"'",' or ',' || ',' and ',' && ',"'or'","'and'");
		$string = str_replace($matchchar,'',$string);
		return $string;
	}
?>
<?php
include("../url.php");
session_start();
if (isset($_SESSION['id']))
{
     $url_data1=$admin_url.'index.php';
     ?>
     <script>
	alert("Logged In");
	 window.location = "<?=$url_data1?>";
	</script>
     <?php
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>video</title>
    <link rel="icon" type="image/x-icon" href="../eklan/logo.png"/>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/users/login-2.css" rel="stylesheet" type="text/css" />
    <style>
    .theme-logo
    {width:20%;}
    </style>
    <!-- END GLOBAL MANDATORY STYLES -->    
</head>
<body class="login">
    <form class="form-login" action="" method="post">
        <div class="row">
            <div class="col-md-12 text-center mb-4">
                <img alt="logo" src="../eklan/logo.png" class="theme-logo">
            </div>
            <div class="col-md-12">
                <label for="inputEmail" class="">Email address</label>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="icon-inputEmail"><i class="flaticon-user-7"></i> </span>
                    </div>
                    <input type="text" name="user" class="form-control user" value="Yourname" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
                </div>
                <label for="inputPassword" class="">Password</label>            
                <div class="input-group mb-4">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="icon-inputPassword"><i class="flaticon-key-2"></i> </span>
                    </div>
                      <input type="password" name="password" class="form-control lock" value="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
                </div>
                <button class="btn btn-lg btn-gradient-warning btn-block btn-rounded mb-4 mt-5" type="submit">Login</button>
            </div>
        </div>
    </form>   
    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->
</body>
</html>