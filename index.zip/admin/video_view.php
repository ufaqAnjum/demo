<?php include("layout/head.php");
?>
<?php

session_start();
if (!isset($_SESSION['id']))
{
     $url_data=$url.'index.php';
     ?>
     <script>
        window.location = "/admin/sign-in.php";
    </script>
     <?php
    exit(header("Location:/".$url_data));
}
?>
<?php 
// select 
$pageslists = array();
?>
<?php 
$i = 1;
$e = 0;
$id=$_GET['id'];
$sql = "SELECT * FROM video where `id`='$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pageslists[$e] = $row;
  $pageslists[$e]['srno'] = $i;
   $i++;
   $e++;
  }
}

?>
  <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>video <small>  Panel</small></h3>
                        <div class="crumbs">
                            <ul id="breadcrumbs" class="breadcrumb">
                                <li><a href="index.html"><i class="flaticon-home-fill"></i></a></li>
                                    <li class="active"><a href="video_list.php">View video</a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="row layout-spacing">
                    <div class="col-lg-12">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>View video</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="row">
                                    <div class="col-lg-12 mb-4">
                                        <blockquote class="blockquote">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped">
                                                <thead class="table-inverse">
                                                    <tr>
                                                        <th></th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                      <?php if(!empty($pageslists)){
							    foreach($pageslists as $value){
							    ?>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Name</th>
                                                        <td><?=$value['name']?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Link</th>
                                                        <td><?=$value['link']?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Image</th>
                                                        <td><img src="../upload/<?=$value['image'];?>" title="image" ></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Category</th>
                                                        <td><?php
                                        $resultssbc =$conn->query("SELECT name,id FROM category WHERE id ='".$value['category_id']."'");
								$rowssbc=$resultssbc->fetch_assoc();
								    echo $rowssbc['name'];                
								    ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Created By</th>
                                                      
                                                        		<td><?php 
								$id=$value['created_by'];
								$sqlu="SELECT name FROM users where id=$id";
								  $resultu = $conn->query($sqlu);
                                $rowu = $resultu->fetch_assoc();
                                    echo $rowu['name'];
								?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Updated By</th>
                                                      
                                                        		<td><?php 
								$id=$value['updated_by'];
								$sqlu="SELECT name FROM users where id=$id";
								  $resultu = $conn->query($sqlu);
                                $rowu = $resultu->fetch_assoc();
                                    echo $rowu['name'];
								?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-nowrap" scope="row">Date</th>
                                                        <td><?=$value['created_at']?></td>
                                                    </tr>
                                                <?php } 
							  } else { ?>
							  <tr><td colspan="6">No Pages</td></tr>
							  <?php } ?>    
                                                </tbody>
                                            </table>
                                        </div>
                                        </blockquote>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php 
$conn->close();
include("layout/foot.php");?> 