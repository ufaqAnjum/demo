<link href="image/favicon.png" rel="icon" />
<!-- BOOTSTRAP CSS -->
<link rel="stylesheet" type="text/css" href="assets/bootstrap-4.2.1/bootstrap.min.css">
<!-- END BOOTSTRAP CSS -->
<!-- OWL CAROUSEL -->
<link rel="stylesheet" type="text/css" href="assets/owlcarousel/owl.carousel.css">
<!-- END OWL CAROUSEL -->
<!-- FONT CSS -->
<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/icofont.min.css">
<link rel="stylesheet" type="text/css" href="assets/owlcarousel/animated.css">
<link rel="stylesheet" type="text/css" href="assets/video/video.popup.css">
<!-- STYLE CSS -->
<link rel="stylesheet" type="text/css" href="assets/css/style.css">
<!-- END STYLE CSS -->
<!-- RESPONSIVE CSS -->
<link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
<link rel="stylesheet" type="text/css" href="assets/css/jPages.css">
<!-- END RESPONSIVE CSS -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CPoppins:200,300,400,500,600,700,800,900" rel="stylesheet">
<script src="assets/js/jquery-3.3.1.min.js"></script>