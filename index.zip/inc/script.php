<script src="assets/vendor/modernizr-3.5.0.js"></script>
    
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/video/video.popup.js"></script>
    <script src="assets/bootstrap-4.2.1/bootstrap.min.js"></script>
    <script src="assets/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/menu/menumaker.js"></script>
    <script src="assets/slick/swiper.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/pagination.js"></script>